class Person:
    def _init_(self):
        self.name = ""
        self.age = ""
        self.mobile = ""

    def set_name(self):
        self.name = input("Enter name: ")

    def set_age(self):
        self.age = input("Enter age: ")

    def set_mobile(self):
        self.mobile = input("Enter mobile number: ")

    def get_name(self):
        return self.name

    def get_age(self):
        return self.age

    def get_mobile(self):
        return self.mobile
person1 = Person()
person1.set_name()
person1.set_age()
person1.set_mobile()
print("Name:", person1.get_name())
print("Age:", person1.get_age())
print("Mobile:", person1.get_mobile())